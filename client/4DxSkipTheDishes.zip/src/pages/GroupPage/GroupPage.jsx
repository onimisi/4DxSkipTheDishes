import React from 'react'

export default function GroupPage() {
    return (
        <div className='main-page-section'>
            Hello
        </div>
    )
}
